@nrp.MapCSVRecorder("recorder", filename="all_spikes.csv", headers=["ID", "Time"])
@nrp.MapSpikeSink("spikes", nrp.brain.LMN, nrp.spike_recorder)
@nrp.Neuron2Robot()
def record_spikes (t, spikes, recorder):
    for entry in range(len(spikes.times)):
         recorder.record_entry(spikes.times[entry][0], spikes.times[entry][1])