@nrp.MapCSVRecorder("recorder", filename="head_angle.csv", headers=["Time", "Theta"])
@nrp.MapVariable("theta_t1", initial_value=0)
@nrp.MapSpikeSource("left", nrp.brain.L, nrp.dc_source)
@nrp.MapSpikeSource("right", nrp.brain.R, nrp.dc_source)
@nrp.Robot2Neuron()
def AHV(t, left, right, theta_t1, recorder):
    from get_head_angle import getHeadAngle
    theta = getHeadAngle(t)[0]
    recorder.record_entry(t,theta)
        
    vel = theta - theta_t1.value
    theta_t1.value = theta
    
    Ivel = vel * 0.35 * 10000

    sh = 150
    go_l,go_r = Ivel,-Ivel
    go_l = go_l+sh
    go_r = go_r+sh
    if go_l<=sh:
        go_l = 0.
    if go_r<=sh:
        go_r = 0.
            
    left.amplitude = go_l
    right.amplitude = go_r