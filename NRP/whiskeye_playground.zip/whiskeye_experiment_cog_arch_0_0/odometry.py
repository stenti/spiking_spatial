Input@nrp.MapRobotSubscriber("topic", Topic("/whiskeye/body/pose", geometry_msgs.msg.Pose2D))
@nrp.Robot2Neuron()
def odometry (t, topic):
    #log the first timestep (20ms), each couple of seconds
    if t % 2 < 0.02:
        clientLogger.info('Theta: ', topic.value.theta)