@nrp.NeuronMonitor(nrp.brain.LMN[slice(0, 180, 1)], nrp.spike_recorder)
def HD_monitor(t):
    return True