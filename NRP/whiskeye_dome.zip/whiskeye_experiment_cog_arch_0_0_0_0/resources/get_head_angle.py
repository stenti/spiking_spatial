import rospy
import tf
import random
import math
import kc_interf
import numpy as np

from std_msgs.msg import *
from sensor_msgs.msg import *
from geometry_msgs.msg import *
from whiskeye_plugin.msg import Bridge_u

class whiskeye_control_data():

    def __init__(self):
        import numpy as np
        self.neck_angles = np.array([0.0, 0.0, 0.0])
        self.body_theta = 0.0

    def head_packet_callback(self, data):
        self.neck_angles[0:3] = data.neck.data[0:3]

    def body_pose_callback(self, data):
        self.body_theta = data.theta

whiskeye_control_data = whiskeye_control_data()

kc = kc_interf.kc_whiskeye()

rospy.Subscriber('/whiskeye/head/bridge_u', Bridge_u, whiskeye_control_data.head_packet_callback, queue_size=1)
rospy.Subscriber('/whiskeye/body/pose', Pose2D, whiskeye_control_data.body_pose_callback, queue_size=1)

def getHeadAngle(tick):
    ## find head pose in body frame
    kc.setConfig(whiskeye_control_data.neck_angles)

    # get location of head centre and fovea in HEAD
    cen_HEAD = np.array([0.0, 0.0, 0.0])
    fov_HEAD = np.array([0.1, 0.0, 0.0])


    # transform to BODY
    cen_BODY = kc.changeFrameAbs(kc_interf.KC_FRAME_HEAD, kc_interf.KC_FRAME_BODY, cen_HEAD)

    fov_BODY = kc.changeFrameAbs(kc_interf.KC_FRAME_HEAD, kc_interf.KC_FRAME_BODY, fov_HEAD)


    # recover head yaw angle
    d = fov_BODY - cen_BODY
    yaw = np.array([np.arctan2(d[1], d[0])])


    # cast head into world frame
    head_theta = whiskeye_control_data.body_theta + yaw

    return head_theta