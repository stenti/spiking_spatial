@nrp.Neuron2Robot(Topic('/whiskeye/body/cmd_vel', geometry_msgs.msg.Twist))
def spinning(t):
    return geometry_msgs.msg.Twist(angular=geometry_msgs.msg.Vector3(x=0.0, y=0.0, z=0.5))