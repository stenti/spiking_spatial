@nrp.MapSpikeSource("view_input", nrp.map_neurons(range(180), lambda i: nrp.brain.LMN[i]), nrp.dc_source)
@nrp.Robot2Neuron()
def predicitons(t, view_input):
    
    # useing prediciton from PCN
    p = prediction*10.
    view_input.amplitude = p