@nrp.Robot2Neuron()
def transferFunction (t):
    clientLogger.info(nrp.config.brain_root.bump_centre)